//
//  DBManager.swift
//  Tree
//
//  Created by Avinash somani on 09/08/17.
//  Copyright © 2017 Kavyasoftech. All rights reserved.
//

import UIKit
class DBManager: NSObject {
    
    var db: OpaquePointer?
    var statement: OpaquePointer?
    
    internal let SQLITE_STATIC = unsafeBitCast(0, to: sqlite3_destructor_type.self)
    internal let SQLITE_TRANSIENT = unsafeBitCast(-1, to: sqlite3_destructor_type.self)
    
    func CreateOpenDB() { //Create/open database.
        
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("gomobiz.sqlite")
        // open database
        
        
        
    
        if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
            print("error opening database")
        }else{
            print("fileURL database----------------\(fileURL)")
        }
    }
    
    func closeDatabase() {
        
        if sqlite3_close(db) != SQLITE_OK {
            print("error closing database")
        }
        
        db = nil
    }
    
    func CreateTable(query: String) { //Use sqlite3_exec to perform SQL (e.g. create table).
        
        //"create table if not exists test (id integer primary key autoincrement, name text)"
        if sqlite3_exec(db, query, nil, nil, nil) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error creating table: \(errmsg)")
        }
    
    }
    func getMaximumId(query:String)->Int {
     //Use sqlite3_prepare_v2 to prepare SQL with ? placeholder to which we'll bind value.
        //"insert into test (name) values (?)" //prepareStatement
        //print("query-\(query)-")
        // select MAX(userid) from SampleTable
        if sqlite3_prepare_v2(db, query, -1, &statement, nil) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error preparing insert: \(errmsg)")
        }
        
        while (sqlite3_step(statement) == SQLITE_ROW) {
         //   int lastInsertedPrimaryKey = sqlite3_column_int(sqlstatement, 0);
        }
        
        if sqlite3_step(statement) != SQLITE_DONE {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("failure inserting foo: \(errmsg)")
        }
        
        
        return 0
    }
    func deleteAllTableRecord(query: String){
      
        if sqlite3_prepare_v2(db, query, -1, &statement, nil) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error preparing insert: \(errmsg)")
        }else {
            
        }
        
        if sqlite3_step(statement) != SQLITE_DONE {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("failure inserting foo: \(errmsg)")
        }else {
            let msg = String(cString: sqlite3_errmsg(db)!)
            print("db success ---> : \(msg)")

        }
        
    }
    
    func prepareStatement(query: String, arrAttributes: NSMutableArray) { //Use sqlite3_prepare_v2 to prepare SQL with ? placeholder to which we'll bind value.
        //"insert into test (name) values (?)" //prepareStatement
   //     print("query-\(query)-")
        
        if sqlite3_prepare_v2(db, query, -1, &statement, nil) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error preparing insert: \(errmsg)")
        }
        
        var y = 0
        
        while y < arrAttributes.count {
            
            if let str = arrAttributes.object(at: y) as? String {
                /**
                 if sqlite3_bind_text(statement, 1, "foo", -1, SQLITE_TRANSIENT) != SQLITE_OK {
                 let errmsg = String(cString: sqlite3_errmsg(db)!)
                 print("failure binding foo: \(errmsg)")
                 }
                 */
                
                if sqlite3_bind_text(statement, Int32(y+1), str, -1, SQLITE_TRANSIENT) != SQLITE_OK {
                    let errmsg = String(cString: sqlite3_errmsg(db)!)
                    print("failure binding foo: \(errmsg)")
                }
            }
            y += 1
        }
        
        
        
        if sqlite3_step(statement) != SQLITE_DONE {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("failure inserting foo: \(errmsg)")
        }
    }
    func statementQuery(query:String) {
        
        if sqlite3_prepare_v2(db, query, -1, &statement, nil) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error preparing select: \(errmsg)")
        }

    }
    
    func statementSelectValues(query: String, completionHandler: (inout OpaquePointer?, OpaquePointer?) -> Void) { //Prepare new statement for selecting values from table and loop through retrieving the values:
        print("query select: \(query)")

        //"select id, name from test"
        if sqlite3_prepare_v2(db, query, -1, &statement, nil) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error preparing select: \(errmsg)")
        }
        
        completionHandler(&statement, db)
        
        //
        //        while sqlite3_step(statement) == SQLITE_ROW {
        
        
        
        
        //
        //            let id = sqlite3_column_int64(statement, 0)
        //            print("id = \(id); ", terminator: "")
        //
        //            if let cString = sqlite3_column_text(statement, 1) {
        //                let name = String(cString: cString)
        //                print("name = \(name)")
        //            } else {
        //                print("name not found")
        //            }
        //        }
        //
        //        if sqlite3_finalize(statement) != SQLITE_OK {
        //            let errmsg = String(cString: sqlite3_errmsg(db)!)
        //            print("error finalizing prepared statement: \(errmsg)")
        //        }
        //
        //        statement = nil
    }
    
    
    func statement(query: String) -> (statement:OpaquePointer?, db:OpaquePointer?) { //Prepare new statement for selecting values from table and loop through retrieving the values:
        
        //"select id, name from test"
        if sqlite3_prepare_v2(db, query, -1, &statement, nil) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error preparing select: \(errmsg)")
        }
        
        return (statement, db)
        
        //
        //        while sqlite3_step(statement) == SQLITE_ROW {
        
        
        
        
        //
        //            let id = sqlite3_column_int64(statement, 0)
        //            print("id = \(id); ", terminator: "")
        //
        //            if let cString = sqlite3_column_text(statement, 1) {
        //                let name = String(cString: cString)
        //                print("name = \(name)")
        //            } else {
        //                print("name not found")
        //            }
        //        }
        //
        //        if sqlite3_finalize(statement) != SQLITE_OK {
        //            let errmsg = String(cString: sqlite3_errmsg(db)!)
        //            print("error finalizing prepared statement: \(errmsg)")
        //        }
        //
        //        statement = nil
    }
    
    
}

class chatMessage: NSObject {
    var IncId : Int64 = 0
    var to : String = ""
    var from : String = ""
    var message : String = ""
    var date : String = ""
}
